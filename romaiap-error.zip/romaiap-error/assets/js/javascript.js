/* Imgs contato */
/* Imgs contato / Telefone */
function mouseEmCimaTelefone(imagem) {
    imagem.src='assets/img/telefone1.png'
}
    
 function mouseForaTelefone(imagem) {
    imagem.src='assets/img/telefone.png'
}


/* Imgs contato / Email */
function mouseEmCimaEmail(imagem) {
    imagem.src='assets/img/gmail.png'
}
    
 function mouseForaEmail(imagem) {
    imagem.src='assets/img/email.png'
}


/* Imgs contato / Linkedin */
function mouseEmCimaLinkedin(imagem) {
    imagem.src='assets/img/linkedin1.png'
}
    
 function mouseForaLinkedin(imagem) {
    imagem.src='assets/img/linkedin.png'
}


/* Imgs contato / Instagram */
function mouseEmCimaInstagram(imagem) {
    imagem.src='assets/img/instagram1.png'
}
    
 function mouseForaInstagram(imagem) {
    imagem.src='assets/img/instagram.png'
}

const popoverTriggerList = document.querySelectorAll('[data-bs-toggle="popover"]')
const popoverList = [...popoverTriggerList].map(popoverTriggerEl => new bootstrap.Popover(popoverTriggerEl))